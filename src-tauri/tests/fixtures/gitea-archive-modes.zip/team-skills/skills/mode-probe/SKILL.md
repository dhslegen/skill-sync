---
name: mode-probe
description: 探测可执行位
---

正文
